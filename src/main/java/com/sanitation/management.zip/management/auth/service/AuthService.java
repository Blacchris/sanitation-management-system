package com.sanitation.management.auth.service;

import com.sanitation.management.auth.dto.AuthResponse;
import com.sanitation.management.auth.dto.CustomerRegistrationRequest;
import com.sanitation.management.auth.dto.LoginRequest;
import com.sanitation.management.auth.dto.OrganizationRegistrationRequest;
import com.sanitation.management.auth.dto.RegistrationResponse;
import com.sanitation.management.auth.dto.VerifyOtpRequest;
import com.sanitation.management.auth.entity.DeliveryChannel;
import com.sanitation.management.auth.entity.OtpEmailOutbox;
import com.sanitation.management.auth.entity.PendingRegistration;
import com.sanitation.management.auth.repository.OtpEmailOutboxRepository;
import com.sanitation.management.auth.repository.PendingRegistrationRepository;
import com.sanitation.management.common.exception.*;
import com.sanitation.management.organization.entity.Organization;
import com.sanitation.management.organization.enums.VerificationStatus;
import com.sanitation.management.organization.repository.OrganizationRepository;
import com.sanitation.management.security.JwtService;
import com.sanitation.management.user.entity.User;
import com.sanitation.management.user.enums.AccountStatus;
import com.sanitation.management.user.enums.Role;
import com.sanitation.management.user.repository.UserRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.security.auth.login.AccountLockedException;
import java.nio.charset.StandardCharsets;
import java.security.GeneralSecurityException;
import java.time.Duration;
import java.time.Instant;
import java.util.Locale;
import java.util.Optional;
import java.util.UUID;

@Service
public class AuthService {

    private static final String REGISTRATION_MESSAGE =
            "A verification code will be sent shortly";

    /** Minimum gap between OTPs for the same email. Throttles spam without letting anyone block the real owner. */
    private static final Duration RESEND_COOLDOWN = Duration.ofSeconds(60);

    private static final int BCRYPT_MAX_BYTES = 72;

    private final UserRepository userRepository;
    private final OrganizationRepository organizationRepository;
    private final PendingRegistrationRepository pendingRegistrationRepository;
    private final OtpEmailOutboxRepository otpEmailOutboxRepository;
    private final PasswordEncoder passwordEncoder;
    private final OtpCipher otpCipher;
    private final OtpService otpService;
    private final JwtService jwtService;
    private final int maxFailedLoginAttempts;
    private final Duration loginLockDuration;

    /** A real BCrypt hash compared against when the email is unknown, so both login paths cost the same time. */
    private final String dummyHash;

    public AuthService(UserRepository userRepository,
                       OrganizationRepository organizationRepository,
                       PendingRegistrationRepository pendingRegistrationRepository,
                       OtpEmailOutboxRepository otpEmailOutboxRepository,
                       PasswordEncoder passwordEncoder,
                       OtpCipher otpCipher,
                       OtpService otpService,
                       JwtService jwtService,
                       @Value("${auth.login.max-failed-attempts:5}") int maxFailedLoginAttempts,
                       @Value("${auth.login.lock-minutes:15}") long lockMinutes) {
        this.userRepository = userRepository;
        this.organizationRepository = organizationRepository;
        this.pendingRegistrationRepository = pendingRegistrationRepository;
        this.otpEmailOutboxRepository = otpEmailOutboxRepository;
        this.passwordEncoder = passwordEncoder;
        this.otpCipher = otpCipher;
        this.otpService = otpService;
        this.jwtService = jwtService;
        this.maxFailedLoginAttempts = maxFailedLoginAttempts;
        this.loginLockDuration = Duration.ofMinutes(lockMinutes);
        this.dummyHash = passwordEncoder.encode("timing-equalisation-" + UUID.randomUUID());
    }

    // ------------------------------------------------------------------
    // Step 1: submit details -> pending registration + outbox row (one transaction, no User yet)
    // ------------------------------------------------------------------

    @Transactional
    public RegistrationResponse registerCustomer(CustomerRegistrationRequest request) {
        String email = normalizeEmail(request.email());
        String phone = request.phone().trim();
        DeliveryChannel channel = request.otpChannel();
        assertAccountAvailable(email, phone);

        PendingRegistration pending = findOrCreatePending(email);
        assertResendAllowed(pending);

        // A newer registration for the same email REPLACES an older pending one: the latest claimant wins,
        // so an attacker who pre-registers someone's email cannot make the real owner verify the attacker's data.
        fillAccount(pending, request.fullName(), email, phone, request.password(), Role.CUSTOMER, channel);
        clearOrganizationDetails(pending);

        return issueOtp(pending, channel);
    }

    @Transactional
    public RegistrationResponse registerOrganization(OrganizationRegistrationRequest request) {
        String email = normalizeEmail(request.email());
        String phone = request.phone().trim();
        String registrationNumber = blankToNull(request.registrationNumber());
        DeliveryChannel channel = resolveChannel(request.otpChannel());

        assertAccountAvailable(email, phone);
        assertRegistrationNumberAvailable(registrationNumber);

        PendingRegistration pending = findOrCreatePending(email);
        assertResendAllowed(pending);

        fillAccount(pending, request.fullName(), email, phone, request.password(), Role.ORGANIZATION, channel);
        pending.setOrganizationName(request.organizationName().trim());
        pending.setRegistrationNumber(registrationNumber);
        pending.setDescription(blankToNull(request.description()));
        pending.setServicesDescription(request.servicesDescription().trim());
        String contactEmail = blankToNull(request.contactEmail());
        pending.setContactEmail(contactEmail == null ? null : normalizeEmail(contactEmail));
        pending.setContactPhone(request.contactPhone().trim());
        pending.setBusinessAddress(request.businessAddress().trim());

        return issueOtp(pending, channel);
    }

    private RegistrationResponse issueOtp(PendingRegistration pendingRegistration, DeliveryChannel channel) {
        String otpText = otpService.generate();
        pendingRegistration.setOtpHash(otpService.hash(pendingRegistration.getEmail(), otpText));
        pendingRegistration.setOtpExpiresAt(Instant.now().plus(otpService.ttl()));
        pendingRegistration.setOtpAttempts(0);

        // For a NEW row this INSERT runs here (IDENTITY), which is what gives us the id the AAD needs.
        // saveAndFlush also surfaces unique-constraint errors now, before any encryption work.
        pendingRegistrationRepository.saveAndFlush(pendingRegistration);

        Long registrationId = pendingRegistration.getId();

        if (registrationId == null) {
            throw new IllegalStateException(
                    "Pending registration must have an ID before encryption"
            );
        }

        byte[] aad = OtpCipher.aadForRegistrationId(registrationId);

        OtpCipher.EncryptedOtp encrypted;

        try {
            encrypted = otpCipher.encrypt(otpText, aad);
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException("Failed to encrypt OTP", e);
        }

        // Re-registering with the same email reuses the row (same id, so the outbox PK is already taken).
        OtpEmailOutbox outbox = otpEmailOutboxRepository.findById(registrationId)
                .orElseGet(OtpEmailOutbox::new);

        outbox.setPendingRegistration(pendingRegistration);
        String destination = channel == DeliveryChannel.SMS
                ? pendingRegistration.getPhone()
                : pendingRegistration.getEmail();
        outbox.setChannel(channel);
        outbox.setRecipient(destination);
        outbox.setOtpCiphertext(encrypted.ciphertext());
        outbox.setOtpNonce(encrypted.nonce());
        outbox.resetDeliveryState(); // status PENDING, attempts 0, due now

        // Same transaction as the pending registration: both commit, or neither exists.
        otpEmailOutboxRepository.save(outbox);

        return new RegistrationResponse(REGISTRATION_MESSAGE, pendingRegistration.getEmail(), channel,
                mask(destination, channel), otpService.ttl().toSeconds());
    }

    // ------------------------------------------------------------------
    // Step 2: prove ownership of the email -> create User (+ Organization) and issue the JWT
    // ------------------------------------------------------------------

    // noRollbackFor is essential: the failed-attempt counter must be COMMITTED even though we throw.
    // With default rollback rules the increment would be undone and the attempt limit would never trigger.
    @Transactional(noRollbackFor = {InvalidOtpException.class, TooManyAttemptsException.class})
    public AuthResponse verifyRegistration(VerifyOtpRequest request) {
        String email = normalizeEmail(request.email());

        // Row lock: concurrent guesses for this email queue up and each sees the latest counter.
        PendingRegistration pending = pendingRegistrationRepository.findByEmailForUpdate(email)
                .orElseThrow(InvalidOtpException::new);

        if (pending.getOtpAttempts() >= otpService.maxAttempts()) {
            throw new TooManyAttemptsException(); // locked out: even the correct code is refused
        }
        if (Instant.now().isAfter(pending.getOtpExpiresAt())) {
            throw new InvalidOtpException();
        }
        if (!otpService.matches(email, request.otp(), pending.getOtpHash())) {
            int attempts = pending.getOtpAttempts() + 1;
            pending.setOtpAttempts(attempts);
            pendingRegistrationRepository.saveAndFlush(pending);
            throw attempts >= otpService.maxAttempts() ? new TooManyAttemptsException() : new InvalidOtpException();
        }

        // Re-check: someone may have registered this email/phone/number since the pending row was created.
        assertAccountAvailable(email, pending.getPhone());
        if (pending.getRole() == Role.ORGANIZATION) {
            assertRegistrationNumberAvailable(pending.getRegistrationNumber());
        }

        User user = new User();
        user.setFullName(pending.getFullName());
        user.setEmail(pending.getEmail());
        user.setPhone(pending.getPhone());
        user.setPasswordHash(pending.getPasswordHash()); // already a BCrypt hash
        user.setRole(pending.getRole());                  // server-decided at step 1
        user.setAccountStatus(AccountStatus.ACTIVE);
        userRepository.saveAndFlush(user);

        Organization organization = null;
        if (pending.getRole() == Role.ORGANIZATION) {
            organization = new Organization();
            organization.setUser(user);
            organization.setOrganizationName(pending.getOrganizationName());
            organization.setRegistrationNumber(pending.getRegistrationNumber());
            organization.setDescription(pending.getDescription());
            organization.setServicesDescription(pending.getServicesDescription());
            organization.setContactEmail(pending.getContactEmail());
            organization.setContactPhone(pending.getContactPhone());
            organization.setBusinessAddress(pending.getBusinessAddress());
            organization.setVerificationStatus(VerificationStatus.PENDING); // OTP != admin verification
            organization.setAcceptingRequests(Boolean.FALSE);
            organizationRepository.saveAndFlush(organization);
        }

        // Child (outbox) first, then parent (pending): the outbox PK is a foreign key to the pending row.
        otpEmailOutboxRepository.deleteById(pending.getId());
        pendingRegistrationRepository.delete(pending);

        return AuthResponse.of(jwtService.generateAccessToken(user), user, organization);
    }

    // ------------------------------------------------------------------
    // Login
    // ------------------------------------------------------------------

    // noRollbackFor is essential: the failure counter / lock must be COMMITTED even though we throw.
    // Under default rollback rules every failed attempt would be undone and brute force would be unlimited.
    @Transactional(noRollbackFor = {InvalidCredentialsException.class, AccountLockedException.class})
    public AuthResponse login(LoginRequest request) throws Exception {
        String email = normalizeEmail(request.email());

        // Row lock: parallel attempts on the same account are processed one at a time.
        Optional<User> found = userRepository.findByEmailForUpdate(email);
        if (found.isEmpty()) {
            passwordEncoder.matches(request.password(), dummyHash); // result ignored: equalizes timing
            throw new InvalidCredentialsException();
        }
        User user = found.get();
        Instant now = Instant.now();

        if (user.getLockedUntil() != null) {
            if (now.isBefore(user.getLockedUntil())) {
                throw new AccountLockedException(); // refused WITHOUT looking at the password
            }
            user.setLockedUntil(null);              // lock has expired: fresh start
            user.setFailedLoginAttempts(0);
        }

        if (!passwordMatches(request.password(), user.getPasswordHash())) {
            int failures = user.getFailedLoginAttempts() + 1;
            user.setFailedLoginAttempts(failures);
            if (failures >= maxFailedLoginAttempts) {
                user.setLockedUntil(now.plus(loginLockDuration));
            }
            userRepository.saveAndFlush(user);
            throw failures >= maxFailedLoginAttempts ? new AccountLockedException("Your account has been locked due to Too many login attempts")
                    : new InvalidCredentialsException();
        }

        // Status is checked only AFTER the password is proven correct, so an outsider cannot probe which
        // emails belong to suspended accounts.
        if (user.getAccountStatus() != AccountStatus.ACTIVE) {
            throw new AccountNotActiveException();
        }

        if (user.getFailedLoginAttempts() != 0) {
            user.setFailedLoginAttempts(0);
            userRepository.saveAndFlush(user);
        }

        // An organization may log in while still unverified; verified-only operations are guarded separately
        // (OrganizationAccess), so a valid token never implies a verified organization.
        Organization organization = user.getRole() == Role.ORGANIZATION
                ? organizationRepository.findByUserId(user.getId()).orElse(null)
                : null;

        return AuthResponse.of(jwtService.generateAccessToken(user), user, organization);
    }

    private boolean passwordMatches(String rawPassword, String storedHash) {
        // BCrypt only uses 72 bytes; passwords created through registration can never be longer.
        if (rawPassword.getBytes(StandardCharsets.UTF_8).length > BCRYPT_MAX_BYTES) {
            passwordEncoder.matches("x", dummyHash); // keep timing uniform
            return false;
        }
        return passwordEncoder.matches(rawPassword, storedHash);
    }

    // ------------------------------------------------------------------
    // helpers
    // ------------------------------------------------------------------

    private PendingRegistration findOrCreatePending(String email) {
        return pendingRegistrationRepository.findByEmailForUpdate(email).orElseGet(PendingRegistration::new);
    }

    /**
     * Only a cooldown, never a refusal: the issue time is derived as (expiry - ttl), so no extra column.
     * Runs after the row lock is taken, and before anything on the row is modified.
     * The message must not tell the caller to use "the code already sent": it may belong to someone else.
     */
    private void assertResendAllowed(PendingRegistration pending) {
        if (pending.getOtpHash() == null) {
            return; // brand-new row, nothing issued yet
        }
        Instant issuedAt = pending.getOtpExpiresAt().minus(otpService.ttl());
        if (Instant.now().isBefore(issuedAt.plus(RESEND_COOLDOWN))) {
            throw new OtpAlreadySentException(
                    "A code was requested recently. Please wait a minute before trying again.");
        }
    }

    private static DeliveryChannel resolveChannel(DeliveryChannel requested) {
        return requested == null ? DeliveryChannel.EMAIL : requested;
    }

    private void fillAccount(PendingRegistration pending, String fullName, String email, String phone,
                             String rawPassword, Role role, DeliveryChannel channel) {
        pending.setFullName(fullName.trim());
        pending.setEmail(email);
        pending.setPhone(phone);
        pending.setPasswordHash(passwordEncoder.encode(rawPassword)); // raw password goes no further than this line
        pending.setRole(role);                                         // never taken from the request
        pending.setChannel(channel);
    }

    // Organization fields only. The channel is NOT cleared here: every registration needs one.
    private void clearOrganizationDetails(PendingRegistration pending) {
        pending.setOrganizationName(null);
        pending.setRegistrationNumber(null);
        pending.setDescription(null);
        pending.setServicesDescription(null);
        pending.setContactEmail(null);
        pending.setContactPhone(null);
        pending.setBusinessAddress(null);
    }

    private void assertAccountAvailable(String email, String phone) {
        if (userRepository.existsByEmail(email)) {
            throw new DuplicateResourceException("Email is already registered");
        }
        if (userRepository.existsByPhone(phone)) {
            throw new DuplicateResourceException("Phone number is already registered");
        }
    }

    private void assertRegistrationNumberAvailable(String registrationNumber) {
        if (registrationNumber != null && organizationRepository.existsByRegistrationNumber(registrationNumber)) {
            throw new DuplicateResourceException("Registration number is already registered");
        }
    }

    private static String mask(String value, DeliveryChannel channel) {
        if (channel == DeliveryChannel.SMS) {
            int keep = Math.min(3, value.length());
            return "*".repeat(value.length() - keep) + value.substring(value.length() - keep);
        }
        int at = value.indexOf('@');
        return at <= 0 ? "***" : value.charAt(0) + "***" + value.substring(at);
    }

    private static String normalizeEmail(String email) {
        return email.trim().toLowerCase(Locale.ROOT);
    }

    // Blank -> null keeps empty strings from colliding on UNIQUE indexes.
    private static String blankToNull(String value) {
        return value == null || value.isBlank() ? null : value.trim();
    }
}