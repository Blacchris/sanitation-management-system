package com.sanitation.management.auth.entity;

import com.sanitation.management.user.enums.Role;
import jakarta.persistence.*;
import jakarta.validation.constraints.NotNull;
import lombok.AccessLevel;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * A registration that has been submitted but not yet proven (via OTP) to own the email address.
 * No User/Organization exists until verification succeeds. No toString on purpose: it would expose hashes.
 */
@Entity
@Table(
        name = "pending_registrations",
        uniqueConstraints = @UniqueConstraint(name = "uk_pending_registrations_email", columnNames = "email")
)
@Getter
@Setter
@NoArgsConstructor
public class PendingRegistration {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Setter(AccessLevel.NONE)
    private Long id;

    // ---- account details (copied into User on success) ----

    @Column(name = "email", nullable = false, length = 254)
    private String email;

    @Column(name = "phone", nullable = false, length = 25)
    private String phone;

    @Column(name = "full_name", nullable = false, length = 120)
    private String fullName;

    /** BCrypt hash. The raw password is never stored, not even temporarily. */
    @Column(name = "password_hash", nullable = false)
    private String passwordHash;

    @Enumerated(EnumType.STRING)
    @Column(name = "role", nullable = false, length = 20)
    private Role role;

    @NotNull
    private DeliveryChannel channel;

    // ---- organization details (null for customers; copied into Organization on success) ----

    @Column(name = "organization_name", length = 150)
    private String organizationName;

    @Column(name = "registration_number", length = 100)
    private String registrationNumber;

    @Column(name = "description", columnDefinition = "TEXT")
    private String description;

    @Column(name = "services_description", columnDefinition = "TEXT")
    private String servicesDescription;

    @Column(name = "contact_email", length = 254)
    private String contactEmail;

    @Column(name = "contact_phone", length = 25)
    private String contactPhone;

    @Column(name = "business_address", length = 500)
    private String businessAddress;

    // ---- OTP state ----

    /** HMAC-SHA256 (hex) of the OTP. The plaintext OTP is never stored on this row. */
    @Column(name = "otp_hash", nullable = false, length = 64)
    private String otpHash;

    @Column(name = "otp_expires_at", nullable = false)
    private Instant otpExpiresAt;

    /** Failed verification attempts for the current OTP. */
    @Column(name = "otp_attempts", nullable = false)
    private int otpAttempts = 0;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @PrePersist
    void onCreate() {
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        this.updatedAt = Instant.now();
    }
}
